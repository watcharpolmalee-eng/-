const CACHE = "senseplay-asd-pwa-v1";
const ASSETS = ["./index.html","./manifest.webmanifest"];
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(()=>self.skipWaiting())
  );
});
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.map(k => (k !== CACHE) ? caches.delete(k) : null)))
      .then(()=>self.clients.claim())
  );
});
self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches.match(event.request).then(cached => cached || fetch(event.request).then(res => {
      try{
        const url = new URL(event.request.url);
        if(event.request.method === "GET" && url.origin === self.location.origin){
          const clone = res.clone();
          caches.open(CACHE).then(cache => cache.put(event.request, clone));
        }
      }catch(e){}
      return res;
    }).catch(()=>cached))
  );
});
