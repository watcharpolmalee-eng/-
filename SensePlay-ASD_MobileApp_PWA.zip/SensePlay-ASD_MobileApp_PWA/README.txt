SensePlay-ASD Mobile (PWA)
==========================

This is a Progressive Web App (PWA) version of the SensePlay-ASD research prototype.
It can be installed on mobile like an app.

Files:
- SensePlay-ASD_MobileApp_PWA/index.html
- SensePlay-ASD_MobileApp_PWA/manifest.webmanifest
- SensePlay-ASD_MobileApp_PWA/sw.js

How to install as an app:
1) Host this folder on HTTPS (recommended):
   - GitHub Pages, Netlify, Vercel, Firebase Hosting
2) Open the URL on your phone:
   - Android Chrome: Menu (⋮) > "Add to Home screen" / Install
   - iPhone Safari: Share > "Add to Home Screen" (PWA install behavior differs on iOS)

Note:
- If you open index.html as a local file on iPhone, "Install" and offline cache may not work.
- Task 2 uses Text-to-Speech. On iOS, tap "Enable audio" once before starting trials.

Research-only. Not diagnostic.
